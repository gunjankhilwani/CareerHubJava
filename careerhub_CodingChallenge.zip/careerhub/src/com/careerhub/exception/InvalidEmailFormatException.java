package com.careerhub.exception;

public class InvalidEmailFormatException extends Exception {

	public InvalidEmailFormatException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidEmailFormatException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
