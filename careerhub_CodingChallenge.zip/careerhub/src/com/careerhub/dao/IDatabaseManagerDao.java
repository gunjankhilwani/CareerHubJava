package com.careerhub.dao;

import java.util.List;

import com.careerhub.entity.Applicant;
import com.careerhub.entity.Company;
import com.careerhub.entity.JobApplication;
import com.careerhub.entity.JobListing;

public interface IDatabaseManagerDao {
	void initializeDatabase();

    void insertJobListing(JobListing job);

    void insertCompany(Company company);

    void insertApplicant(Applicant applicant);

    void insertJobApplication(JobApplication application);

    List<JobListing> getJobListings();

    List<Company> getCompanies();

    List<Applicant> getApplicants();

    List<JobApplication> getApplicationsForJob(int jobID);

}
