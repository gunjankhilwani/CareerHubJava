package com.careerhub.dao;

import java.util.List;

import com.careerhub.entity.Applicant;

public class JobListingDaoImpl implements IJobListingDao {

	@Override
	public void apply(int applicantID, String coverLetter) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<Applicant> getApplicants() {
		// TODO Auto-generated method stub
		return null;
	}

}
