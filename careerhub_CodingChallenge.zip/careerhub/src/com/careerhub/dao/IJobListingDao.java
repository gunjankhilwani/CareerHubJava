package com.careerhub.dao;

import java.util.List;

import com.careerhub.entity.*;

public interface IJobListingDao {
	
	void apply(int applicantID, String coverLetter);
    List<Applicant> getApplicants();

}
