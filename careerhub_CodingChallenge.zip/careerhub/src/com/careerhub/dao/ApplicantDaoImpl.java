package com.careerhub.dao;
import com.careerhub.entity.*;
import com.careerhub.exception.*;
import com.careerhub.Service.*;
import com.careerhub.util.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ApplicantDaoImpl implements IApplicantDao {

		PreparedStatement preparedStatement;
		Statement statement;
		ResultSet resultSet;
		@Override
		public void createProfile(Applicant profile) {
			try {
				Connection connection = DBUtil.createConnection();
				
				preparedStatement = connection.prepareStatement("INSERT INTO Applicant(FirstName,LastName, Email, Phone) VALUES (?,?,?,?)");
				preparedStatement.setString(1,profile.getFirstName());
				preparedStatement.setString(2,profile.getLastName());
				preparedStatement.setString(3,profile.getEmail());
				preparedStatement.setString(4,profile.getPhone());

				int row= preparedStatement.executeUpdate();
				if(row==1)
				{
					System.out.println("Done Done");
				}
				else {
					System.out.println("Not Done");
				}
			}catch(SQLException e) {
				e.printStackTrace();
			}

		}

		@Override
		public void applyForJob(int jobID, String coverLetter) {
			

		}

	}



