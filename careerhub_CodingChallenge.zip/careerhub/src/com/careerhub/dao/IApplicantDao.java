package com.careerhub.dao;

import com.careerhub.entity.Applicant;

public interface IApplicantDao {
	
	void createProfile(Applicant Profile);
    void applyForJob(int jobID, String coverLetter);
}
