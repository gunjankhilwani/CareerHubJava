package com.careerhub.dao;

import java.util.List;

import com.careerhub.entity.Applicant;
import com.careerhub.entity.Company;
import com.careerhub.entity.JobApplication;
import com.careerhub.entity.JobListing;

public class DataManagerDaoImpl implements IDatabaseManagerDao {

	@Override
	public void initializeDatabase() {
		// TODO Auto-generated method stub

	}

	@Override
	public void insertJobListing(JobListing job) {
		// TODO Auto-generated method stub

	}

	@Override
	public void insertCompany(Company company) {
		// TODO Auto-generated method stub

	}

	@Override
	public void insertApplicant(Applicant applicant) {
		// TODO Auto-generated method stub

	}

	@Override
	public void insertJobApplication(JobApplication application) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<JobListing> getJobListings() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Company> getCompanies() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Applicant> getApplicants() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<JobApplication> getApplicationsForJob(int jobID) {
		// TODO Auto-generated method stub
		return null;
	}

}
