package com.careerhub.dao;

import java.util.List;
import com.careerhub.entity.*;

public interface ICompanyDao {
	
	void postJob(String jobTitle, String jobDescription, String jobLocation, double salary, String jobType);

	void postJob(JobListing jb);
}
