package com.careerhub.main;

import java.sql.Connection;
import java.util.Scanner;
import com.careerhub.util.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;

import com.careerhub.util.DBUtil;
import com.careerhub.dao.*;
import com.careerhub.entity.*;
import com.careerhub.exception.*;
import com.careerhub.service.ApplicantServiceImpl;
import com.careerhub.service.CompanyServiceImpl;
import com.careerhub.service.DatabaseManagerServiceImpl;
import com.careerhub.service.JobListingServiceImpl;
import com.careerhub.Service.*;

public class MainModule {
	static ApplicantServiceImpl apsrvc=new ApplicantServiceImpl();
	static CompanyServiceImpl cpsrvc=new CompanyServiceImpl();
	static JobListingServiceImpl jbsrvc=new JobListingServiceImpl();
	static DatabaseManagerServiceImpl dbsrvc=new DatabaseManagerServiceImpl();
	public static void main(String[] args) {
		int choice = -1;
		Scanner sc = new Scanner(System.in);
		while (choice != 0) {
			System.out.println("1. Applicant");
			System.out.println("2. Company");
			System.out.println("3. Job Application");
			System.out.println("4. Job Listing");
			System.out.println("5. Database Manager");
			System.out.println("0. Exit");
			System.out.println("Plese Enter your choice");

			choice = sc.nextInt();
            sc.nextLine();
            switch (choice) {
			case 1:
				ApplicantView();
				break;
			case 2:
				CompanyView();
				break;
			case 3:
				JobApplicationView();
				break;
			case 4:
				JoblistingView();
				break;
			case 5:
				DatabaseManagerView();
				break;
			case 0:
				System.out.println("You are out of careerhub");
				break;
			default:
				System.out.println("Invalid choice. Please try again.");
				break;
            }
	}
 
}

	private static void DatabaseManagerView() {
		// TODO Auto-generated method stub
		
	}

	private static void JoblistingView() {
		// TODO Auto-generated method stub
		
	}

	private static void JobApplicationView() {
		// TODO Auto-generated method stub
		
	}

	private static  void CompanyView() {
		int choice = -1;
		Scanner sc = new Scanner(System.in);
		while (choice != 0) {
			System.out.println("1.Post Job");
			System.out.println("2. Get Job");
			System.out.println("0.Exit");
		   choice=sc.nextInt();
		   sc.nextLine();
		   switch (choice) {
			case 1:
				Company cmp=new Company();
				JobListing jb =new JobListing();
				System.out.println("Enter the Company Id");
				cmp.setCompanyID(sc.nextInt());
				sc.nextLine();
				jb.setCompany(cmp);
				System.out.println("Enter the Job Title");
				jb.setJobTitle(sc.nextLine());
				
				System.out.println("Enter the Job Description");
				jb.setJobDescription(sc.nextLine());
				
				System.out.println("Enter the Job Location");
				jb.setJobLocation(sc.nextLine());
				
				System.out.println("Enter the Salary");
				jb.setSalary(sc.nextFloat());
				sc.nextLine();
				
				System.out.println("Enter the Job Type");
				jb.setJobType(sc.nextLine());
				
				jb.setPostedDate(LocalDate.now());
				cpsrvc.postJob(jb);
				break;
			case 2:
				CompanyView();
				break;
			case 0:
				System.out.println("You are out of Applicant");
				break;
			default:
				System.out.println("Invalid choice. Please try again.");
				break;
			
		}
		
		
	}
		
	}

	private static void ApplicantView() {
		int choice = -1;
		Scanner sc = new Scanner(System.in);
		while (choice != 0) {
			System.out.println("1. Create Profile");
			System.out.println("2. ApplyForJob");
			System.out.println("0.Exit");
		   choice=sc.nextInt();
		   sc.nextLine();
		   switch (choice) {
			case 1:
				Applicant profile=new Applicant();
				System.out.println("Enter the firstname");
				profile.setFirstName(sc.nextLine());
				
				System.out.println("Enter the LastName");
				profile.setLastName(sc.nextLine());
				
				System.out.println("Enter the email");
				profile.setEmail(sc.nextLine());
				
				System.out.println("Enter the phone");
				profile.setPhone(sc.nextLine());
				
				apsrvc.CreateProfile(profile);
				break;
			case 2:
				CompanyView();
				break;
			case 0:
				System.out.println("You are out of Applicant");
				break;
			default:
				System.out.println("Invalid choice. Please try again.");
				break;
			
		}
		
		
	}

}
	}
