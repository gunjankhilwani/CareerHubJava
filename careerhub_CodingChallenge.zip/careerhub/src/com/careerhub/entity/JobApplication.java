package com.careerhub.entity;

import java.time.LocalDate;

public class JobApplication {
	private int applicationID;
    private int jobID;
    private int applicantID;
    private LocalDate applicationDate;
    private String coverLetter;
    
    public JobApplication() {}

    public JobApplication(int applicantID, int jobID, String coverLetter,LocalDate applicationDate) {
        this.applicationID = applicationID;
        this.jobID = jobID;
        this.applicantID = applicantID;
        this.applicationDate = applicationDate;
        this.coverLetter = coverLetter;
    }

}
