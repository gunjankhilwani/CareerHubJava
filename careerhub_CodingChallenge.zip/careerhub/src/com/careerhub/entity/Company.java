package com.careerhub.entity;

import java.util.ArrayList;
import java.time.LocalDate;
import java.util.*;
import java.util.List;

public class Company {
	private int companyID;
    private String companyName;
    private String location;
    private List<JobListing> jobListings;
    
    public Company() {}

    public Company(int companyID, String companyName, String location) {
        this.companyID = companyID;
        this.companyName = companyName;
        this.location = location;
        this.jobListings = new ArrayList<>();
    }

	public int getCompanyID() {
		return companyID;
	}

	public void setCompanyID(int companyID) {
		this.companyID = companyID;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public List<JobListing> getJobListings() {
		return jobListings;
	}

	public void setJobListings(List<JobListing> jobListings) {
		this.jobListings = jobListings;
	}

   
	

}
