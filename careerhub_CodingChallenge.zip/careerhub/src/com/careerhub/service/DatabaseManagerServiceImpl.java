package com.careerhub.service;

import com.careerhub.entity.Applicant;
import com.careerhub.entity.Company;
import com.careerhub.entity.JobApplication;
import com.careerhub.entity.JobListing;

public class DatabaseManagerServiceImpl implements IDatabaseManagerService {

	@Override
	public void initializeDatabase() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insertJobListing(JobListing job) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insertCompany(Company company) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insertApplicant(Applicant applicant) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insertJobApplication(JobApplication application) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getJobListings() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getCompanies() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getApplicants() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getApplicationsForJob(int jobID) {
		// TODO Auto-generated method stub
		
	}
	
}
