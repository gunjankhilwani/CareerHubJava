package com.careerhub.service;
import java.util.List;

public interface IJobListingService {
void apply();
    
	void getApplicant();

}
