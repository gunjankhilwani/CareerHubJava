package com.careerhub.service;

import com.careerhub.entity.*;
import com.careerhub.dao.*;

public class ApplicantServiceImpl implements IApplicantService {
	ApplicantDaoImpl obj1=new ApplicantDaoImpl();

    @Override
	public void CreateProfile(Applicant profile) {
		
			obj1.createProfile(profile);
			
	

	}

	@Override
	public void Applyforjob(int jobid, String coverletter) {
		
			obj1.applyForJob(jobid,coverletter);
			
		

	}

}
