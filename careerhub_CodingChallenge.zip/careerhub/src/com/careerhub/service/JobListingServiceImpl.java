package com.careerhub.service;

public class JobListingServiceImpl implements IJobListingService {

	@Override
	public void apply() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getApplicant() {
		// TODO Auto-generated method stub
		
	}
	
}
