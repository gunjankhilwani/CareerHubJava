package com.careerhub.service;

import com.careerhub.entity.Applicant;
import com.careerhub.entity.Company;
import com.careerhub.entity.JobApplication;
import com.careerhub.entity.JobListing;

public interface IDatabaseManagerService {
	void initializeDatabase();

    void insertJobListing(JobListing job);

    void insertCompany(Company company);

    void insertApplicant(Applicant applicant);

    void insertJobApplication(JobApplication application);

    void getJobListings();

    void getCompanies();

    void getApplicants();

    void getApplicationsForJob(int jobID);
}
