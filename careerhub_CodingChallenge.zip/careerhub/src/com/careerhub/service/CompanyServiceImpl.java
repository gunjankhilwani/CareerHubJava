package com.careerhub.service;

import com.careerhub.dao.CompanyDaoImpl;
import com.careerhub.entity.JobListing;

public class CompanyServiceImpl implements ICompanyService {
	CompanyDaoImpl obj= new CompanyDaoImpl();
	@Override
	public void postJob(JobListing jb) {
		
      obj.postJob(jb);
	}

	@Override
	public void getJobs() {
		// TODO Auto-generated method stub

	}
}
