package com.careerhub.service;

import com.careerhub.entity.Applicant;

public interface IApplicantService {

	void Applyforjob(int jobid, String coverletter);

	void CreateProfile(Applicant profile);
	

}
